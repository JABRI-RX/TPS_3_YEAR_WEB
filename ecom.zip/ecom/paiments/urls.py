from django.urls import path

from paiments.views import home

urlpatterns = [
    path('',home)
]
