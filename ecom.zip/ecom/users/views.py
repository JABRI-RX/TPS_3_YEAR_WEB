from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def register(request):
    return HttpResponse("<h1>Welcome To Registration Page<h1>")

def login(request):
    return HttpResponse("<h1>Welcome To Login Page<h1>")

def change_password(request):
    return HttpResponse("<h1>Welcome To change password Page<h1>")

def hello(request):
    return HttpResponse("<h1>Hello, Welcome to this website<h1>")

def hello_name(request,name):
    return HttpResponse(f"<h1> Hello {name}, Welcome to this website</h1>")

def hello_name_age(request,name,age):
    return HttpResponse(f"<h1> Hello {name},You Are {age} years old, Welcome to this website</h1>")