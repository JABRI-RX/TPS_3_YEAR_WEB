from django.urls import path
from users.views import register,login,change_password,hello,hello_name,hello_name_age
urlpatterns = [
    path("register/",register),
    path("login/",login),
    path("change-password/",change_password),
    path("hello/",hello),
    path("hello/<str:name>/",hello_name),
    path("hello/<str:name>/<int:age>/",hello_name_age),
]
