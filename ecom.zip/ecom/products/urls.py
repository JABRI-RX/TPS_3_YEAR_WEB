from django.urls import path
from products.views import list_products,list_by_date,list_by_name

urlpatterns = [
    path('',list_products),
    path('<int:year>/',list_by_date),
    path('<str:name>/',list_by_name)
]
