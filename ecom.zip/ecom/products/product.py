class Product:
    def __init__(self,name,brand,date) :
        self.name = name
        self.brand = brand
        self.date = date