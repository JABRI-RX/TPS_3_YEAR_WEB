from django.shortcuts import render
from django.http import HttpResponse
from products.product import Product
product_s = []
product_s.append(Product('Macbook Air', 'Apple', 2021))
product_s.append(Product('Macbook Air', 'Apple', 2020))
product_s.append(Product('Macbook Pro', 'Apple', 2021))
product_s.append(Product('Macbook Pro', 'Apple', 2020))
product_s.append(Product('Thinkpad X', 'Lenovo', 2018))
product_s.append(Product('EliteBook', 'Hp', 2018))
product_s.append(Product('Airpods Pro', 'Apple', 2020))


# Create your views here.
def list_products(request):
    
    resulat = "<h1>Products</h1>"
    resulat += "<ul><br>"
    for prod in product_s:
        
        resulat += f"<li> {prod.name} - {prod.date} from {prod.brand}</li>"
    resulat += "</ul><br>"
    return HttpResponse(resulat)

def list_by_date(request,year):
    resulat = "<h1>Products</h1>"
    resulat += "<ul><br>"
    for prod in product_s:
        if prod.date == year:
            resulat += f"<li> {prod.name} - {prod.date} from {prod.brand}</li>"
    resulat += "</ul><br>"
    return HttpResponse(resulat)

def list_by_name(request,name):
    resulat = "<h1>Products</h1>"
    resulat += "<ul><br>"
    for prod in product_s:
        if prod.name == name:
            resulat += f"<li> {prod.name} - {prod.date} from {prod.brand}</li>"
    resulat += "</ul><br>"
    return HttpResponse(resulat)